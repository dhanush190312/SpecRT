# RadioPath

Isocenter sequence optimization for radiotherapy treatment plans.

Reads a DICOM-RT plan → extracts isocenter coordinates → builds a 3D-distance
cost matrix → optimizes the visiting order with **2-opt** → validates against
the exact **Held-Karp** solution on small cases → prints and saves a
comparison report.

This is a **sequencing prototype only**. It does not change dose, beam
parameters, treatment technique, or the clinical plan, and it does **not**
perform collision detection.

## 1. Install

```bash
pip install -r requirements.txt
```

(Just three packages: `pydicom`, `pandas`, `numpy`.)

## 2. Where to get an input file

You need a DICOM-RT **Plan** file (Modality = `RTPLAN`). Three options, easiest first:

**A. Generate a synthetic test file (no real patient data, works offline):**
```bash
python generate_sample_rtplan.py --output sample_rtplan.dcm --n 6
```
This creates `sample_rtplan.dcm` with 6 random isocenters and 1–3 beams per
isocenter, purely for testing the pipeline.

**B. Use pydicom's own bundled sample RT Plan** (ships with the `pydicom`
package, no download needed):
```python
from pydicom.data import get_testdata_file
print(get_testdata_file("rtplan.dcm"))  # prints a local path you can pass to main.py
```

**C. Use a real DICOM-RT plan** exported from your TPS/PACS (anonymized as
needed for your institution's policy). Any file with `Modality = RTPLAN` and
a populated `BeamSequence` will work.

## 3. Run it

```bash
python main.py sample_rtplan.dcm
```

Options:
```bash
python main.py plan.dcm --open              # optimize an open path (no return leg)
python main.py plan.dcm --outdir results     # change where CSV files are saved
```

## 4. Where the output goes

Everything prints to the console **and** is saved as CSV files (default
folder: `output/`, or whatever you pass to `--outdir`):

| File | Contents |
|---|---|
| `output/input_points.csv` | Extracted isocenters (label, X, Y, Z, source beams) |
| `output/cost_matrix.csv` | Full pairwise 3D-distance cost matrix |
| `output/results.csv` | Initial / 2-opt / Held-Karp cost + route comparison |

Console output includes, in order: the input points table, the cost matrix,
the initial/2-opt/Held-Karp comparison table, the before/after route, and the
percentage gap between the 2-opt heuristic and the exact optimum.

## 5. Project structure

```
radiopath_project/
├── main.py                    # CLI entry point — run this
├── generate_sample_rtplan.py  # creates a synthetic test .dcm file
├── requirements.txt
└── radiopath/
    ├── models.py               # Isocenter data class
    ├── dicom_reader.py         # pydicom: read plan, extract isocenters
    ├── cost_matrix.py          # NumPy: pairwise 3D Euclidean distances
    ├── tsp_2opt.py             # 2-opt heuristic (main algorithm)
    ├── tsp_held_karp.py        # Held-Karp exact DP (small-n validation)
    └── report.py               # console + CSV formatting
```

## 6. How isocenters are extracted

Each beam in `BeamSequence` stores its isocenter in the `IsocenterPosition`
tag of its **first control point**. Multiple beams often share one physical
isocenter (e.g. several arcs at one couch position), so beams whose
positions match to within 0.1 mm are merged into a single point (`P1`, `P2`,
...) and their beam names are kept for reference.

## 7. Algorithm notes

- **2-opt** (main): removes two edges from the route, reconnects the other
  way, keeps the change if it lowers total cost, repeats until no improving
  move remains. ~O(n³) worst case. A heuristic — not guaranteed optimal.
- **Held-Karp** (validation only): exact dynamic-programming TSP solver,
  O(n²·2ⁿ) time. Only run when the point count is ≤ 13 (`MAX_PRACTICAL_N` in
  `tsp_held_karp.py`) since the exponential term makes it impractical beyond
  that — for larger plans, the report simply shows the 2-opt result.

## 8. Limitations

- 3D straight-line Euclidean distance is used as a movement-cost proxy; it is
  **not** a validated real-machine movement-time model.
- No collision detection, gantry/couch constraint checking, or machine
  geometry modeling — this is explicitly future scope.
- Held-Karp is a benchmark for small cases, not the production algorithm.
